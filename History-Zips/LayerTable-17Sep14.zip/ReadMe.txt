Product: Layer Table, September 2014

Designer: Jens Dyvik, http://www.dyvikdesign.com/

Support:  support@obrary.com

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary is a marketplace of products collaboratively designed by the community. These products can be produced by anyone, amateur or professional manufacturer, wherever economically or locally practical.

Description:
The Layer Table is designed to be printed on the CNC Router.  It can be made from plywood or MDF.